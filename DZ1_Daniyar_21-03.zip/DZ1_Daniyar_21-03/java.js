var pass = 123
var name = prompt('Введите своё имя');
var lastname = prompt('Введите свою фамилию')
var password = prompt('Введите пароль')
if (password == pass){
    alert('Добро пожаловать!', name + ' ' + lastname );
}else {
    alert('Попробуйте ещё раз', name + ' ' + lastname )
}
